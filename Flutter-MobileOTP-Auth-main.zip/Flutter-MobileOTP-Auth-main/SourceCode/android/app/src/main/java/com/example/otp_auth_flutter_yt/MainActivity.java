package com.example.otp_auth_flutter_yt;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
